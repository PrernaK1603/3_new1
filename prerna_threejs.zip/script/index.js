var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
var renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

var controls = new THREE.OrbitControls(camera, renderer.domElement);

window.addEventListener("resize", function () {
    var width = window.innerWidth;
    var height = window.innerHeight;
    renderer.setSize(width, height);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
});


//shape creation
var geometry = new THREE.BoxGeometry(1, 1, 1);
// create a material and color
var material = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: false });
var cube = new THREE.Mesh(geometry, material);
scene.add(cube);
camera.position.z = 3;
controls.update();

//game logic

function keyFunc() {
    document.addEventListener('keydown', function () {
        switch (event.keyCode) {
            case 37:
                cube.rotation.x += 0.01;
                break;
            case 38:
                cube.rotation.z += 0.01;
                break;
            case 39:
                cube.rotation.y += 0.02;
                break;
            case 40:
                cube.rotation.x -= 0.01;
                break;
            default:
                cube.rotation.y += 0.01;
                break;
        }
    })
}

var count = 0;
var box = document.querySelector("canvas");
function zoomFunc(){
    if (count % 2 != 0) {
        box.addEventListener("dblclick", function () {
            cube.scale.x = 1;
            cube.scale.y = 1;
            cube.scale.z = 1;
        });
    } else {
        box.addEventListener("dblclick", function () {
            cube.scale.x = 2;
            cube.scale.y = 2;
            cube.scale.z = 3;
        });
    }
    count++;
}

var updates = function () {
    keyFunc();
    zoomFunc();
}

//draw scene
var render = function () {
    renderer.render(scene, camera);
}

var GameLoop = function () {
    requestAnimationFrame(GameLoop);
    updates();
    controls.update();
    render();
}
GameLoop();